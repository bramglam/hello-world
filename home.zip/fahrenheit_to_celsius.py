def fahrenheit_to_celsius(temp_in_fahren):
    temp_in_c=(temp_in_fahren - 32) * 5/9
    return temp_in_c
