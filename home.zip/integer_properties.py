def integer_properties(num):
    if num%2 !=0:
        print('Odd')
    elif num%2 == 0:
        print('Even')
    if num>0:
        print('Positive')
    elif num<0:
        print('Negative')
    elif num==0:
        print('Zero')

    
