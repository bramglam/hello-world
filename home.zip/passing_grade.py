def passing_grade(number_grade):
    if number_grade >= 70:
        return True
    elif number_grade <=70 and number_grade>=0:
        return False
